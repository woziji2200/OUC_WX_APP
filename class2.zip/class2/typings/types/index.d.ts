/// <reference path="./wx/index.d.ts" />
